<!DOCTYPE html>
<html lang="en">
<head>
    <!-- ========== Meta Tags ========== -->
    <meta name="msvalidate.01" content="9CEC8F910627C5DECF2342A3DF20EC6C" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="World’s biggest online test series for NEET, JEE MAIN & ADVANCED/IIT, MBBS admission in abroad, MBBS in Kazakhstan & Belarus">
    <meta name="keywords" content="JEE MAIN test series, online test series, jee main test series, best test series, for jee main, best test series, JEE ADVANCED, premium, test series, jee advanced, crack jee main, IIT, crack NEET, unique questions, best test series for NEET, best notes for JEE MAIN, best notes for IIT, best notes for NEET preparation, success in NEET, success in JEE MAIN, success in IIT, large question bank, psychologically designed notes for board exam preparation, MBBS in abroad, MBBS admission in Kazakhstan, MBBS admission in Belarus, best universities, best MBBS consultants, best education consultant, Transparent services, best support for admission process, free consulting for B.E./B.Tech admission, best online test series for medical and engineering aspirants, mbbs aspirants, engineering aspirants, students, XIITH Students, CBSE board, icse board, best, notes, for any board preparation">

    <!-- ========== Page Title ========== -->
    <title><?=$this->site_setting['site_name'];?></title>

    <!-- ========== Favicon Icon ========== -->
    <link rel="shortcut icon" href="<?=base_url('uploads/logo/'.$this->site_setting['favicon']);?>" type="image/x-icon">

    <!-- ========== Start Stylesheet ========== -->
    <link href="<?=base_url('assets/frontend/css/bootstrap.min.css');?>" rel="stylesheet" />
   <link href="
https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.1.0/css/all.css" rel="stylesheet">
    <link href="<?=base_url('assets/frontend/css/flaticon-set.css');?>" rel="stylesheet" />
    <link href="<?=base_url('assets/frontend/css/magnific-popup.css');?>" rel="stylesheet" />
    <link href="<?=base_url('assets/frontend/css/owl.carousel.min.css');?>" rel="stylesheet" />
    <link href="<?=base_url('assets/frontend/css/owl.theme.default.min.css');?>" rel="stylesheet" />
    <link href="<?=base_url('assets/frontend/css/animate.css');?>" rel="stylesheet" />
    <link href="<?=base_url('assets/frontend/css/bootsnav.css');?>" rel="stylesheet" />
    <link href="<?=base_url('assets/frontend/style.css');?>" rel="stylesheet">
    <link href="<?=base_url('assets/frontend/css/responsive.css');?>" rel="stylesheet" />
    <!-- ========== End Stylesheet ========== -->
	<script src="<?=base_url('assets/frontend/js/jquery-1.12.4.min.js');?>"></script>	
     
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="<?=base_url('assets/frontend/js/html5/html5shiv.min.js');?>"></script>
      <script src="<?=base_url('assets/frontend/js/html5/respond.min.js');?>"></script>
    <![endif]-->

    <!-- ========== Google Fonts ========== -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800" rel="stylesheet">
    <?php if($page_data['slug']!='jee-main' && $page_data['slug']!='mbbs-admission'){?>
<script>
<?php $model = array('mbbs_model','mbbs_model_marathi','jee_model');
shuffle($model);?>
var x = '<?php echo $model[0];?>';
 $(window).load(function(){        
   //$('#'+x).modal('show');
   //$('#mbbs_model').modal('show');
   //$('#mbbs_model_marathi').modal('show');
   //$('#jee_model').modal('show');
  setTimeout(function(){
  $('#'+x).modal('hide')
}, 5000);
    }); 
</script>
<?php }?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-153610222-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-153610222-1');
</script>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KQB5NTC');</script>
<!-- End Google Tag Manager -->
</head>

<body>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KQB5NTC"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

    <!-- Preloader Start -->
    <div class="se-pre-con"></div>
    <!-- Preloader Ends -->

    <!-- Start Header Top 
    ============================================= -->
    <div class="top-bar-area address-two-lines bg-dark text-light">
        <div class="container">
            <div class="row">
                <div class="col-md-8 address-info">
                    <div class="info box">
                        <ul>
                            
                            <li style="font-size:24px;">
                               <i class="fas fa-envelope-open"></i> <?=$this->site_setting['email'];?>
                            </li>
                            <li style="font-size:24px;">
                                <i class="fas fa-phone"></i> <?=$this->site_setting['phone'];?>
                            </li>
                        </ul>
                    </div>
                </div>
                 <div class="user-login text-right col-md-4">
                    <a href="<?php echo base_url('web/registration');?>">
                        <i class="fas fa-edit"></i> Register
                    </a>
                    <a  href="<?php echo base_url('web/login');?>">
                        <i class="fas fa-user"></i> Login
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top -->

    <!-- Header 
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default attr-border navbar-sticky bootsnav">


            <div class="container">

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?=base_url();?>">
                        <img src="<?=base_url('uploads/logo/'.$this->site_setting['logo']);?>" class="logo" alt="Logo">
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav navbar-right" data-in="#" data-out="#" style="margin-top: 25px !important;">
                        <li>
                            <a href="<?=base_url();?>">Home</a>
                        </li>
                        <li>
                            <a href="<?=base_url('web/page/about-us');?>">About us</a>
                        </li>
                         <li class="dropdown">
                            <a href="#" class="dropdown-toggle active" data-toggle="dropdown" >Test Series</a>
                            <ul class="dropdown-menu">
                                <li><a href="<?=base_url('web/page/neet');?>">NEET</a></li>
                                <li><a href="<?=base_url('web/page/jee-main');?>">JEE MAIN</a></li>
                                <li><a href="<?=base_url('web/page/jee-advanced');?>">JEE ADVANCED</a></li>
                                <li><a href="<?=base_url('web/page/notes');?>">NOTES</a></li>
                                
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle active" data-toggle="dropdown" >Study MBBS Abroad</a>
                            <ul class="dropdown-menu">
                                <li><a href="<?=base_url('web/page/mbbs-admission');?>">ADMISSION</a></li>
                                <li><a href="<?=base_url('web/page/mbbs-admission-in-belarus');?>">BELARUS</a></li>
                                <li><a href="<?=base_url('web/page/mbbs-admission-in-kazakhstan');?>">KAZAKHSTAN</a></li>
                                <li><a href="<?=base_url('web/page/support');?>">SUPPORT</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?=base_url('web/page/services');?>">Services</a>
                        </li>
                        <li>
                            <a href="<?=base_url('web/faq');?>">FAQ</a>
                        </li>
                        <li>
                            <a href="<?=base_url('web/contact');?>">contact</a>
                        </li>
                        
                        <!--<li class="dropdown">
                            <a href="#" class="dropdown-toggle active" data-toggle="dropdown" >Courses</a>
                            <ul class="dropdown-menu">
                                <li><a href="courses.html">Courses Carousel One</a></li>
                                
                            </ul>
                        </li>-->
                        
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header -->

 