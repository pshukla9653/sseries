 <!-- Start Footer 
    ============================================= -->
    <footer class="bg-fixed shadow dark-hard default-padding-top textext-light">
        <div class="container">
            <div class="row">
                <div class="f-items">
                    <div class="col-md-4 item">
                        <div class="f-item">
                            
                            <p style="text-align:justify;">
                                S Series is run by West Coast Education  for engineering and medical aspirants. Our focused, conceptual and comprehensive approach will help students to crack competitive exams like JEE Main, JEE Advanced and NEET to pursue B.E./B.Tech and MBBS/BDS degrees respectively. You start from learning, re-visioning , understanding and practicing the subject. But with our Test Series you gain perfection. 
                                </p>
                            
                            <div class="subscribe">
                               <form action="#">
                                    <div class="input-group stylish-input-group">
                                        <input type="email" placeholder="Enter your e-mail here" class="form-control" name="email">
                                        <button type="submit">
                                            <i class="fa fa-paper-plane"></i>
                                        </button>  
                                    </div>
                                </form> 
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-6 item">
                        <div class="f-item link">
                            <h4>Links</h4>
                            <ul>
                               <li>
                            <a href="<?=base_url();?>">HOME</a>
                        </li>
                                <li>
                            <a href="<?=base_url('web/page/about-us');?>">ABOUT US</a>
                        </li>
                                <li><a href="<?=base_url('web/page/neet');?>">NEET</a></li>
                               <li><a href="<?=base_url('web/page/jee-main');?>">JEE MAIN</a></li>
                                <li><a href="<?=base_url('web/page/jee-advanced');?>">JEE ADVANCED</a></li>
                         <li>
                            <a href="<?=base_url('web/faq');?>">FAQ</a>
                        </li>
                        <li>
                            <a href="<?=base_url('web/contact');?>">CONTACT</a>
                        </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-2 col-sm-6 item">
                        <div class="f-item link">
                            <h4>More Links</h4>
                            <ul>
                                 <li><a href="<?=base_url('web/page/mbbs-admission');?>">ADMISSION</a></li>
                                <li><a href="<?=base_url('web/page/mbbs-admission-in-belarus');?>">BELARUS</a></li>
                                <li><a href="<?=base_url('web/page/mbbs-admission-in-kazakhstan');?>">KAZAKHSTAN</a></li>
                                <li><a href="<?=base_url('web/page/support');?>">SUPPORT</a></li>
                                <li>
                            <a href="<?=base_url('web/page/services');?>">SERVICES</a>
                        </li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-4 item">
                        <div class="f-item address">
                            <h4>Address</h4>
                            <ul>
                                <li>
                                    <i class="fas fa-envelope"></i> 
                                    <p>Email <span><a href="mailto:<?=$this->site_setting['email'];?>"><?=$this->site_setting['email'];?></a></span></p>
                                </li>
                                <li>
                                    <i class="fas fa-map"></i> 
                                    <p>Office <span style="text-transform: capitalize;"><?=$this->site_setting['address'];?></span></p>
                                </li>
                            </ul>
                           
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Start Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-4">
                            <p>&copy; Copyright 2019. All Rights Reserved by <a href="#">West Coast Education</a></p>
                        </div>
                        <div class="col-md-4">
                        
                        <div style="text-align:center;"><a href="https://info.flagcounter.com/WRh2"><img src="https://s01.flagcounter.com/count/WRh2/bg_FFFFFF/txt_000000/border_CCCCCC/columns_4/maxflags_12/viewers_0/labels_0/pageviews_0/flags_0/percent_0/" alt="Flag Counter" border="0"></a></div>
                        </div>
                        <div class="col-md-4 text-right link">
                            <ul>
                                <li>
                                    <a href="<?=base_url('web/page/privacy-policy');?>">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="<?=base_url('web/page/terms-and-conditions');?>">Terms and Conditions</a>
                                    
                                </li>
                              
                            </ul>
                            <a href="http://cztn.co.in" target="_blank">Design &amp; Developed By : CZTN</a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- End Footer Bottom -->
    </footer>
    <!-- End Footer -->

    <!-- jQuery Frameworks
    ============================================= -->
    
    <script src="<?=base_url('assets/frontend/js/bootstrap.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/equal-height.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/jquery.appear.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/jquery.easing.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/jquery.magnific-popup.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/modernizr.custom.13711.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/owl.carousel.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/wow.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/isotope.pkgd.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/imagesloaded.pkgd.min.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/count-to.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/bootsnav.js');?>"></script>
    <script src="<?=base_url('assets/frontend/js/main.js');?>"></script>
<script>
		window.setTimeout(function () {
			$(".alert-success").fadeTo(300, 0).slideUp(300, function () {
				$(this).remove();
			});
		}, 10000);
    	window.setTimeout(function () {
			$(".alert-info").fadeTo(300, 0).slideUp(300, function () {
				$(this).remove();
			});
		}, 3000);
		window.setTimeout(function () {
			$(".alert-danger").fadeTo(300, 0).slideUp(300, function () {
				$(this).remove();
			});
		}, 10000);
    
		window.setTimeout(function () {
			$(".alert-warning").fadeTo(300, 0).slideUp(300, function () {
				$(this).remove();
			});
		}, 10000);
    
	
    </script>
</body>

</html>